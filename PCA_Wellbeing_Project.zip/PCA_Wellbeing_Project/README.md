
PCA-Based Community Well-Being Policy Monitoring Project

This project uses PCA and Sparse PCA to reduce high-dimensional community well-being indicators
into interpretable latent dimensions and provides a Gradio dashboard for policy monitoring.

Run order:
1. generate_dataset.py
2. pca_spca_pipeline.py
3. gradio_app.py
