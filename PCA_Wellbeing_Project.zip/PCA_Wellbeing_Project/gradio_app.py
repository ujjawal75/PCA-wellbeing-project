
import gradio as gr
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, SparsePCA

def wellbeing_pipeline(csv_file):
    df = pd.read_csv(csv_file.name)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df)

    pca = PCA(n_components=80, random_state=42)
    X_reduced = pca.fit_transform(X_scaled)

    spca = SparsePCA(
        n_components=8,
        alpha=1.5,
        random_state=42,
        max_iter=600,
        tol=1e-3
    )

    X_spca = spca.fit_transform(X_reduced)

    scores = pd.DataFrame(
        X_spca,
        columns=[
            "Economic Stability",
            "Public Health Quality",
            "Educational Access",
            "Environmental Sustainability",
            "Community Safety",
            "Housing & Living Conditions",
            "Infrastructure Development",
            "Social Inclusion"
        ]
    )

    plt.figure()
    scores.mean().plot(kind="bar")
    plt.title("Community Well-Being Policy Dashboard")
    plt.tight_layout()
    plt.show()

    return scores.head()

app = gr.Interface(
    fn=wellbeing_pipeline,
    inputs=gr.File(label="Upload Well-Being CSV"),
    outputs=gr.Dataframe(label="Latent Well-Being Scores"),
    title="PCA-Based Community Well-Being Policy Monitoring"
)

app.launch()
