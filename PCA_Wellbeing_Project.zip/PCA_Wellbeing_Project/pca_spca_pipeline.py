
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, SparsePCA

df = pd.read_csv("community_wellbeing_data.csv")

scaler = StandardScaler()
X_scaled = scaler.fit_transform(df)

pca = PCA(n_components=80, random_state=42)
X_reduced = pca.fit_transform(X_scaled)

spca = SparsePCA(
    n_components=8,
    alpha=1.5,
    random_state=42,
    max_iter=600,
    tol=1e-3
)

X_spca = spca.fit_transform(X_reduced)

scores = pd.DataFrame(
    X_spca,
    columns=[
        "Economic Stability",
        "Public Health Quality",
        "Educational Access",
        "Environmental Sustainability",
        "Community Safety",
        "Housing & Living Conditions",
        "Infrastructure Development",
        "Social Inclusion"
    ]
)

scores.to_csv("wellbeing_scores.csv", index=False)
print("Pipeline completed. Scores saved.")
