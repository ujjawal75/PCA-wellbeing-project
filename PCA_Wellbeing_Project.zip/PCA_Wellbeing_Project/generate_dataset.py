
import numpy as np
import pandas as pd

np.random.seed(42)

n_communities = 5000
domains = {
    "Health": 60,
    "Education": 50,
    "Economy": 70,
    "Environment": 40,
    "Safety": 40,
    "Housing": 40
}

feature_names = []
for domain, count in domains.items():
    for i in range(count):
        feature_names.append(f"{domain}_Indicator_{i+1}")

n_features = len(feature_names)

latent_factors = np.random.randn(n_communities, 6)
weights = np.random.randn(6, n_features)
noise = np.random.normal(0, 0.4, size=(n_communities, n_features))

data = latent_factors @ weights + noise

df = pd.DataFrame(data, columns=feature_names)
df.to_csv("community_wellbeing_data.csv", index=False)

print("Dataset generated:", df.shape)
